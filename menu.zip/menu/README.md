
## Plugin de menú MBU





### Autores

- [Angel Lugo](https://gitlab.com/Angel17x)
- [Leonardo Melo](https://gitlab.com/Lmelo56)
- [Uliangely Cádiz](https://gitlab.com/Uliangely)



### Instalar plugin personalizado en local

Clonar el proyecto

```bash
  git clone https://gitlab.com/wordpress2270650/plugins/menu.git
```

Ir al directorio del proyecto de wordpress

```bash
cd my-project/wp-content/plugins 

```
Pegar la carpeta clonanda en:

```bash
my-project/wp-content/plugins 

```
Desde la shell (opcional)

```bash

# Para Windows

Copy-Item -Path "Ruta\De\La\CarpetaOrigen" -Destination "Ruta\De\La\CarpetaDestino" -Recurse

# Para linux

cp -r /ruta/de/la/carpeta/origen /ruta/de/la/carpeta/destino

# Para Mac

cp -R /ruta/de/la/carpetaOrigen /ruta/de/la/carpetaDestino
```


### Activar el plugin


Inicia el servidor xampp/wampserver o el de tu preferencia y activa el plugin


![App Screenshot](https://gitlab.com/wordpress2270650/imagenes/imagenes-readme/-/raw/main/menu-plugin.png)


### Tecnologías

![WordPress](https://img.shields.io/badge/WordPress-%2321759B.svg?logo=wordpress&logoColor=white)

![PHP](https://img.shields.io/badge/php-%23777BB4.svg?&logo=php&logoColor=white)