<?php

function create_menu_hierarchy($items) {
  $menu_items = [];

  // Primero, convertimos todos los ítems en un formato manejable
  foreach ($items as $item) {
    $menu_item = [
        'ID' => $item->ID,
        'menu_item_parent' => $item->menu_item_parent,
        'title' => $item->title
    ];

    // Agregar 'atributos' solo si no está vacío o no es null
    if (!empty($item->attr_title)) {
      $menu_item['attribute']  = $item->attr_title;
    }

    // Agregar 'url' solo si no está vacío o no es null
    if (!empty($item->url)) {
      if (!empty($item->url) && strpos($item->url, 'category/sin-categoria') === false) {

        if ($item->attr_title == 'Button') {
            // Si es un botón, verificamos si la URL contiene https
            if (strpos($item->url, 'https://') !== false) {
                $menu_item['url'] = $item->url;
            } else {
                // Opcional: puedes manejar el caso cuando no tiene https
                $menu_item['url'] = ''; // o algún valor por defecto
                $menu_item['action'] = str_replace(['http://', 'https://'], '', $item->url);
            }
        } else {
            // Si no es un botón, asignamos la URL directamente           
            $menu_item['url'] = $item->url;
            if ($item->attr_title == 'Link'){
               $menu_item['externalLink'] = true;
            }else{
               $menu_item['externalLink'] = false;
            }
        }
         // Extraer el slug de la URL
         $parsed_url = parse_url($item->url);
         if(!$item->attr_title == 'Button'){
          if (isset($parsed_url['path'])) {
              $path_components = explode('/', trim($parsed_url['path'], '/'));
              if (!empty($path_components[0])) {
                  
                if($path_components[0] == 'category'){
                  if(!empty( $path_components[2])){
                    $menu_item['slug'] = $path_components[2];
                  }else{
                      $menu_item['slug'] = $path_components[1];
                  }

                }else{
                  $menu_item['slug'] = $path_components[0];
                } 
              }
          }
         }

        
      }
    }

    // Agregar 'desacripcción' solo si no está vacío o no es null
    if (!empty($item->description)) {
      if($item->object == 'page'){
        $menu_item['subUrl'] = $item->description;
      }else{
        $menu_item['icon'] = $item->description;
      }
      
    }

    if (!empty($item->classes)) {
      // Verificar si $item->classes es un array y si no está vacío o no contiene solo cadenas vacías
      if (is_array($item->classes)) {
          $non_empty_classes = array_filter($item->classes, function($class) {
              return !empty($class);
          });
          if (!empty($non_empty_classes)) {
              if($item->attr_title == 'Button'){
                $menu_item['classes'] = $item->classes;
              }
              else{
                $menu_item['icon'] = $item->classes;
              }
          }
      } else {
          // Si no es un array, agregarlo directamente
          if($item->attr_title == 'Button'){
            $menu_item['classes'] = $item->classes;
          }
          else{
            $menu_item['icon'] = $item->classes;
          }
      }
  }

    $menu_items[$item->ID] = $menu_item;
  }

  // Construimos la jerarquía añadiendo cada hijo a su respectivo padre
  foreach ($menu_items as $key => &$node) {
    if ($node['menu_item_parent'] != 0) {
        $menu_items[$node['menu_item_parent']]['items'][] = &$node;
    }
  }

  // Recorrer los elementos para asignar el título del padre a los hijos
  foreach ($menu_items as &$node) {
    if (!empty($node['items'])) {
        foreach ($node['items'] as &$child) {
          $child['mainUrl'] = $node['title']; // Asignar el título del padre al hijo
          $child['breadScrumb'] = get_parent_titles($menu_items, $child['menu_item_parent']);
          $data = get_parent_titles2($menu_items, $child['menu_item_parent']);
      
          if ($node['title'] != 'Conoce') {
              // Convertir a minúsculas y reemplazar espacios por _
              $data = replace_character_special($data);
              $child['mainUrl'] = str_replace(' ', '-', mb_strtolower($data, 'UTF-8'));
          } else {
              $child['mainUrl'] = mb_strtolower($node['title'], 'UTF-8');
          }
      }
    }
}

// Eliminamos los nodos que no son raíz para dejar solo los elementos de nivel superior
foreach ($menu_items as $key => &$node) {
    if ($node['menu_item_parent'] != 0) {
        unset($menu_items[$key]);
    }
}

// Eliminar 'mainUrl' de los nodos que no tienen 'slug'
function remove_mainUrl_without_slug(&$menu_items) {
  foreach ($menu_items as &$node) {
      if (isset($node['items'])) {
          remove_mainUrl_without_slug($node['items']);
      }
      if (!isset($node['slug']) && isset($node['mainUrl'])) {
          unset($node['mainUrl']);
      }
  }
}

remove_mainUrl_without_slug($menu_items);
remove_breadScrumb_without_slug($menu_items);


  // Retornamos el array reorganizado
  return array_values($menu_items);
}

// Eliminar 'breadScrumb' de los nodos que no tienen 'slug'
function remove_breadScrumb_without_slug(&$menu_items) {
    foreach ($menu_items as &$node) {
        if (isset($node['items'])) {
            remove_breadScrumb_without_slug($node['items']);
        }
        if (!isset($node['slug']) && isset($node['breadScrumb'])) {
            unset($node['breadScrumb']);
        }
    }
}

function get_parent_titles($menu_items, $parent_id) {
    $titles = [];
    while ($parent_id != 0) {
        if (isset($menu_items[$parent_id])) {
            $titles[] = $menu_items[$parent_id]['title'];
            $parent_id = $menu_items[$parent_id]['menu_item_parent'];
        } else {
            break;  // Si no hay más padres, salimos del ciclo
        }
    }
    
    // Invertimos el array para que vaya de padre a hijo
    return array_reverse($titles);
}

function get_parent_titles2($menu_items, $parent_id) {
  $titles = [];
  while ($parent_id != 0) {
      if (isset($menu_items[$parent_id])) {
          $titles[] = $menu_items[$parent_id]['title'];
          $parent_id = $menu_items[$parent_id]['menu_item_parent'];
      } else {
          break;  // Si no hay más padres, salimos del ciclo
      }
  }
  
  // Invertimos el array para que vaya de padre a hijo
  $titles = array_reverse($titles);
  
  // Unimos los títulos con /
  return implode('/', $titles);
}

function create_menu_footer($items) {
  $menu_items = [];
  $sidebar = get_relation_menu2();
  // Primero, convertimos todos los ítems en un formato manejable
  foreach ($items as $item) {
    $menu_item = [
        'ID' => $item->ID,
        'menu_item_parent' => $item->menu_item_parent,
        'title' => $item->title
    ];

    // Agregar 'atributos' solo si no está vacío o no es null
    if (!empty($item->attr_title)) {
      $menu_item['attribute']  = $item->attr_title;
    }

    // Agregar 'url' solo si no está vacío o no es null
    if (!empty($item->url)) {
      if (!empty($item->url) && strpos($item->url, 'category/sin-categoria') === false) {

        if ($item->attr_title == 'Button') {
            // Si es un botón, verificamos si la URL contiene https
            if (strpos($item->url, 'https://') !== false) {
                $menu_item['url'] = $item->url;
            } else {
                // Opcional: puedes manejar el caso cuando no tiene https
                $menu_item['url'] = ''; // o algún valor por defecto
                $menu_item['action'] = str_replace(['http://', 'https://'], '', $item->url);
            }
        } else {
            // Si no es un botón, asignamos la URL directamente
            $menu_item['url'] = $item->url;
        }
         // Extraer el slug de la URL
         $parsed_url = parse_url($item->url);
         if(!$item->attr_title == 'Button'){
          if (isset($parsed_url['path'])) {
              $path_components = explode('/', trim($parsed_url['path'], '/'));
              if (!empty($path_components[0])) {
                  
                if($path_components[0] == 'category'){
                  if(!empty( $path_components[2])){
                    $menu_item['slug'] = $path_components[2];
                  }else{
                      $menu_item['slug'] = $path_components[1];
                  }

                }else{
                  $menu_item['slug'] = $path_components[0];
                } 
              }
          }
         }

        
      }
    }

    // Agregar 'desacripcción' solo si no está vacío o no es null
    if (!empty($item->description)) {
      if($item->object == 'page')
        $menu_item['subUrl'] = $item->description;
      else
      $menu_item['icon'] = $item->description;
    }

    if (!empty($item->classes)) {
      // Verificar si $item->classes es un array y si no está vacío o no contiene solo cadenas vacías
      if (is_array($item->classes)) {
          $non_empty_classes = array_filter($item->classes, function($class) {
              return !empty($class);
          });
          if (!empty($non_empty_classes)) {
              if($item->attr_title == 'Button'){
                $menu_item['classes'] = $item->classes;
              }
              else{
                $menu_item['icon'] = $item->classes;
              }
          }
      } else {
          // Si no es un array, agregarlo directamente
          if($item->attr_title == 'Button'){
            $menu_item['classes'] = $item->classes;
          }
          else{
            $menu_item['icon'] = $item->classes;
          }
      }
  }

    $menu_items[$item->ID] = $menu_item;
  }

  // Construimos la jerarquía añadiendo cada hijo a su respectivo padre
  foreach ($menu_items as $key => &$node) {
    if ($node['menu_item_parent'] != 0) {
        $menu_items[$node['menu_item_parent']]['items'][] = &$node;
    }
  }

  // Recorrer los elementos para asignar el título del padre a los hijos
  foreach ($menu_items as &$node) {
    if (!empty($node['items'])) {
        foreach ($node['items'] as &$child) {
          $child['mainUrl'] = $node['title']; // Asignar el título del padre al hijo
          $child['breadScrumb'] = get_parent_titles($menu_items, $child['menu_item_parent']);
          $data = get_parent_titles2($menu_items, $child['menu_item_parent']);
      
          if ($node['title'] != 'Conoce') {
              // Convertir a minúsculas y reemplazar espacios por
              $path = get_normal_breadScrumb2($sidebar,$child['slug']);
              $path2 = "";
              if(!empty($path)){
                $path2 = implode('/', $path);
              }
              $path2 = replace_character_special($path2);
              $path2 = preg_replace('/\s+/', '-', mb_strtolower($path2, 'UTF-8'));
              $child['mainUrl'] = $path2;
          } else {
              $child['mainUrl'] = mb_strtolower($node['title'], 'UTF-8');
          }
      }
    }
}

// Eliminamos los nodos que no son raíz para dejar solo los elementos de nivel superior
foreach ($menu_items as $key => &$node) {
    if ($node['menu_item_parent'] != 0) {
        unset($menu_items[$key]);
    }
}

// Eliminar 'mainUrl' de los nodos que no tienen 'slug'
function remove_mainUrl_without_slug(&$menu_items) {
  foreach ($menu_items as &$node) {
      if (isset($node['items'])) {
          remove_mainUrl_without_slug($node['items']);
      }
      if (!isset($node['slug']) && isset($node['mainUrl'])) {
          unset($node['mainUrl']);
      }
  }
}

remove_mainUrl_without_slug($menu_items);
remove_breadScrumb_without_slug($menu_items);


  // Retornamos el array reorganizado
  return array_values($menu_items);
}


function get_normal_breadScrumb2($sidebar,$slug){
    $breadcrumb = '';
    $breadcrumbJ = null;
    foreach ($sidebar['data'] as $menu) {
        if (!empty($menu['items']) && find_breadcrumb_recursive2($menu['items'], $slug, $breadcrumbJ)) {
            break; // Si encontramos, salimos del bucle
        }
    }
    return $breadcrumbJ;
}


function get_relation_menu2() {
    $base_url = get_site_url(); // o home_url()
    $url = $base_url . '/wp-json/wp/v1/menu/sidebar-personas';

    $response = wp_remote_get($url);
  
    if (is_wp_error($response)) {
        return false;
    }
  
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);


    return $data;
}

// Función recursiva mejorada para buscar el breadcrumb
function find_breadcrumb_recursive2($items, $slug, &$result) {
    foreach ($items as $item) {
        // Verificar si es el item buscado
        if (isset($item['slug']) && $item['slug'] === $slug) {
            if (isset($item['breadScrumb'])) {
                $result = $item['breadScrumb'];
                return true; // Encontrado, detener búsqueda
            }
            return false;
        }
        
        // Buscar en subitems si existen
        if (!empty($item['items']) && find_breadcrumb_recursive($item['items'], $slug, $result)) {
            return true; // Propagamos el true si se encontró en subitems
        }
    }
    return false;
}

function replace_character_special($path){
    $path = str_replace(
      ['á', 'é', 'í', 'ó', 'ú', 'ñ', 'ü', 'Á', 'É', 'Í', 'Ó', 'Ú', 'Ñ', 'Ü'],
      ['a', 'e', 'i', 'o', 'u', 'n', 'u', 'A', 'E', 'I', 'O', 'U', 'N', 'U'],
      $path
  );
  return $path;
}

?>