<?php

function custom_rest_api_menus() {  
  // Endpoint para obtener todos los menús  
  register_rest_route('wp/v1', '/menu', array(  
      'methods' => 'GET',  
      'callback' => 'get_menus',  
      'permission_callback' => '__return_true', // Permitir acceso sin permisos  
  ));  
  // Endpoint para obtener un menú específico por Nombre  
  register_rest_route('wp/v1', '/menu/(?P<name>[a-zA-Z0-9-]+)', array(
      'methods' => 'GET',
      'callback' => 'get_menu_by_name',
      'permission_callback' => '__return_true', // Permitir acceso sin permisos
  ));
  // Endpoint para obtener un menú específico por ID  
  register_rest_route('wp/v1', '/menu/(?P<id>[0-9-]+)', array(
    'methods' => 'GET',
    'callback' => 'get_menu_by_id',
    'permission_callback' => '__return_true', // Permitir acceso sin permisos
));
} 


?>