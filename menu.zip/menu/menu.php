<?php

/*
Plugin Name: Menú
Description: Obtiene datos del menú a través de un endpoint personalizado
Version: 1.0
Authors: Uliangely Cádiz, Angel Lugo y Leonardo Melo
*/

include_once 'utils/create_menu_hierarchy.php';
include_once 'functions/functions.php';
include_once 'routes/routes.php';

add_action('rest_api_init', 'custom_rest_api_menus')

?>