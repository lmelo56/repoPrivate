<?php


include_once __DIR__ . '/../utils/create_menu_hierarchy.php';

 
function get_menus() {
    try {
        $menus = wp_get_nav_menus();

        if (empty($menus)) {
            throw new Exception('No se encontraron menús disponibles.', 404);
        }

        $menu_items = [];
        foreach ($menus as $menu) {
            $items = wp_get_nav_menu_items($menu->term_id);
            $menu_items[] = [
                'id' => $menu->term_id,
                'name' => $menu->name,
                'items' => $items ? $items : [], 
            ];
        }

        return new WP_REST_Response(['data' => $menu_items, 'status' => 200], 200);

    } catch (Exception $e) {
        $status = $e->getCode() ? $e->getCode() : 500;
        return new WP_REST_Response(['message' => $e->getMessage(), 'status' => $status], $status);
    }
}
 

/**
 * Obtiene un objeto de menú basado en el nombre del menú proporcionado y devuelve una respuesta REST con los elementos del menú.
 *
 * Esta función busca un menú por su nombre utilizando la función de WordPress `wp_get_nav_menu_object`.
 * Si el menú existe, recupera los elementos del menú y organiza la jerarquía de estos elementos. 
 * La respuesta es devuelta como un objeto `WP_REST_Response` que incluye los datos del menú y el código de estado HTTP.
 *
 * @param array $param Un array asociativo que debe contener la clave 'name' con el valor del nombre del menú.
 * @return WP_REST_Response Regresa una respuesta REST. En caso de éxito, devuelve los datos del menú y el estado HTTP 200.
 *                          En caso de error, devuelve un mensaje de error y el estado HTTP apropiado.
 *
 * @throws Exception Lanza una excepción si el nombre del menú no es proporcionado o si el menú o sus elementos no se encuentran.
 */
function get_menu_by_name($param) {
    try {
        if (empty($param['name'])) {
            throw new Exception('El nombre del menú no fue proporcionado.', 400);
        }

        $menu_name = $param['name'];
        $menu = wp_get_nav_menu_object($menu_name);

        if (!$menu) {
            throw new Exception('No se encontró el menú.', 404);
        }

        $items = wp_get_nav_menu_items($menu->term_id);

        if (!$items) {
            throw new Exception('No se encontraron elementos en el menú.', 404);
        }

        if($menu_name == 'footer'){
            $menu = create_menu_footer($items);
        }else{
            $menu = create_menu_hierarchy($items);
        }
        
        return new WP_REST_Response(['data' => $menu, 'status' => 200], 200);

    } catch (Exception $e) {
        $status = $e->getCode() ? $e->getCode() : 500;
        return new WP_REST_Response(['message' => $e->getMessage(), 'status' => $status], $status);
    }
}

function get_menu_by_id($param) {
    try {
        if (empty($param['id'])) {
            throw new Exception('El nombre del menú no fue proporcionado.', 400);
        }

        $menu_id = $param['id'];
        $menu = wp_get_nav_menu_object($menu_id);

        if (!$menu) {
            throw new Exception('No se encontró el menú.', 404);
        }

        $items = wp_get_nav_menu_items($menu->term_id);

        if (!$items) {
            throw new Exception('No se encontraron elementos en el menú.', 404);
        }

        $menu = create_menu_hierarchy($items);
        return new WP_REST_Response(['data' => $menu, 'status' => 200], 200);

    } catch (Exception $e) {
        $status = $e->getCode() ? $e->getCode() : 500;
        return new WP_REST_Response(['message' => $e->getMessage(), 'status' => $status], $status);
    }
}


?>